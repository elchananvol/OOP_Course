/**
 * Small utility classes
 * @author Dan Nirel
 */
package danogl.util;